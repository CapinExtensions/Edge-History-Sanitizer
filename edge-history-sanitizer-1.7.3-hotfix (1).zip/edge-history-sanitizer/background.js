
// v1.7.3-hotfix: call setupContextMenus & compileRules at startup, guard refresh(), and add extra logging.
const STORAGE_DEFAULTS = {
  rules: [],
  counters: { deletedCount: 0, lastReset: new Date().toISOString().slice(0,10) },
  logs: [],
  events: []
};

function log(...args){ try{ console.log('[EHS]', ...args); }catch(e){} }
function warn(...args){ try{ console.warn('[EHS]', ...args); }catch(e){} }

function isISODateString(s) { return typeof s === 'string' && /\d{4}-\d{2}-\d{2}T/.test(s); }
function normalizeHost(h) { return (h || '').replace(/^www\./, ''); }

async function getState() {
  const data = await chrome.storage.sync.get(STORAGE_DEFAULTS);
  const counters = data.counters ?? STORAGE_DEFAULTS.counters;
  if (isISODateString(counters.lastReset)) {
    counters.lastReset = new Date(counters.lastReset).toISOString().slice(0,10);
    await chrome.storage.sync.set({ counters });
  }
  return {
    rules: data.rules ?? STORAGE_DEFAULTS.rules,
    counters,
    logs: data.logs ?? STORAGE_DEFAULTS.logs,
    events: data.events ?? STORAGE_DEFAULTS.events
  };
}

function escapeRegex(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function patternToRegex(rule) {
  const pattern = (rule.pattern || '').trim();
  if (!pattern) return null;
  switch (rule.type) {
    case 'domain': {
      const escaped = escapeRegex(pattern).replace(/\\\*/g, '.*');
      return new RegExp(`^https?:\\/\\/(?:[^\\/]*\\.)?${escaped}(?:\\/|$)`, 'i');
    }
    default: { return new RegExp(escapeRegex(pattern), 'i'); }
  }
}

let compiledRules = [];
async function compileRulesFromStorage() {
  const { rules } = await getState();
  compiledRules = rules.filter(r => r && (r.enabled !== false))
    .map(r => ({ rule: r, regex: patternToRegex(r) }))
    .filter(x => x.regex);
  log('compiledRules', compiledRules.length);
}

function matchRule(url) { for (const cr of compiledRules) { if (cr.regex.test(url)) return cr.rule; } return null; }

async function recordDeletion(matchedRule, url, source) {
  const state = await getState();
  state.counters.deletedCount += 1;
  const ts = Date.now();
  state.events.push({ ts });
  const oneYearAgo = Date.now() - 365*24*60*60*1000;
  state.events = state.events.filter(e => e.ts >= oneYearAgo);
  if (!(matchedRule.type === 'domain' && matchedRule.hidden === true)) { state.logs.push({ url, source, ts }); }
  await chrome.storage.sync.set({ counters: state.counters, logs: state.logs, events: state.events });
}

async function deleteIfMatched(url, source) {
  if (!url || !compiledRules.length) return;
  const matchedRule = matchRule(url);
  if (!matchedRule) return;
  try { await chrome.history.deleteUrl({ url }); await recordDeletion(matchedRule, url, source); }
  catch (e) { warn('deleteIfMatched failed', url, e); }
}

async function purgeExistingHistory() {
  await compileRulesFromStorage();
  if (!compiledRules.length) return;
  const FIVE_YEARS_MS = 5*365*24*60*60*1000;
  const startTime = Date.now() - FIVE_YEARS_MS;
  let lastEndTime = Date.now();
  const BATCH = 2000;
  try {
    while (true) {
      const items = await chrome.history.search({ text: '', startTime, endTime: lastEndTime, maxResults: BATCH });
      if (!items || items.length === 0) break;
      for (const it of items) { await deleteIfMatched(it.url, 'auto-purge'); }
      const oldest = items[items.length - 1];
      if (!oldest || !oldest.lastVisitTime) break;
      lastEndTime = oldest.lastVisitTime - 1;
      if (lastEndTime <= startTime) break;
      await new Promise(r => setTimeout(r, 50));
    }
  } catch (e) { warn('purgeExistingHistory failed', e); }
}

function setupContextMenus() {
  try {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({ id: 'ehs-parent', title: 'History Sanitizer', contexts: ['page'] });
      chrome.contextMenus.create({ id: 'ehs-add-domain', parentId: 'ehs-parent', title: 'Add current site (Domain)', contexts: ['page'] });
      chrome.contextMenus.create({ id: 'ehs-add-keyword', parentId: 'ehs-parent', title: 'Add current URL as keyword', contexts: ['page'] });
      chrome.contextMenus.create({ id: 'ehs-remove-domain', parentId: 'ehs-parent', title: 'Remove current site (Domain)', contexts: ['page'] });
      log('context menus created');
    });
  } catch (e) { warn('setupContextMenus failed', e); }
}

// Guarded refresh
function refreshMenusSafe(){ try{ if (chrome.contextMenus.refresh) chrome.contextMenus.refresh(); }catch(e){ warn('refresh not available', e); } }

chrome.contextMenus.onShown.addListener(async (info, tab) => {
  try {
    const pageUrl = info.pageUrl || tab?.url;
    let enabled = true;
    if (pageUrl) {
      const u = new URL(pageUrl);
      const host = normalizeHost(u.hostname);
      const state = await getState();
      enabled = (state.rules || []).some(r => r.type === 'domain' && normalizeHost(r.pattern) === host);
    }
    await chrome.contextMenus.update('ehs-remove-domain', { enabled });
    refreshMenusSafe();
  } catch (e) { warn('onShown update failed', e); }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const pageUrl = info.pageUrl || tab?.url; if (!pageUrl) return;
  const u = new URL(pageUrl); const hostname = normalizeHost(u.hostname);
  if (info.menuItemId === 'ehs-add-domain') {
    const { rules } = await getState(); rules.push({ pattern: hostname, type: 'domain', enabled: true, hidden: false });
    await chrome.storage.sync.set({ rules }); await compileRulesFromStorage(); await purgeExistingHistory();
  } else if (info.menuItemId === 'ehs-add-keyword') {
    const { rules } = await getState(); rules.push({ pattern: pageUrl, type: 'keyword', enabled: true });
    await chrome.storage.sync.set({ rules }); await compileRulesFromStorage(); await purgeExistingHistory();
  } else if (info.menuItemId === 'ehs-remove-domain') {
    const { rules } = await getState(); const idx = rules.findIndex(r => r.type === 'domain' && normalizeHost(r.pattern) === hostname);
    if (idx >= 0) { rules.splice(idx, 1); await chrome.storage.sync.set({ rules }); await compileRulesFromStorage(); }
  }
});

chrome.runtime.onInstalled.addListener(async () => { await compileRulesFromStorage(); setupContextMenus(); chrome.runtime.openOptionsPage(); });
chrome.runtime.onStartup?.addListener(async () => { setupContextMenus(); await compileRulesFromStorage(); });
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
chrome.storage.onChanged.addListener(async (changes, area) => { if (area === 'sync' && changes.rules) await compileRulesFromStorage(); });
chrome.history.onVisited.addListener(async (item) => { await deleteIfMatched(item.url, 'history.onVisited'); });
chrome.webNavigation.onCommitted.addListener(async (details) => { if (details.url && details.frameId === 0) setTimeout(() => { deleteIfMatched(details.url, 'webNavigation.onCommitted'); }, 300); });
chrome.runtime.onMessage.addListener((msg, _, sendResponse) => { (async () => {
  if (msg.type === 'getState') { const state = await getState(); const cutoff = Date.now() - 30*24*60*60*1000; const count30 = (state.events || []).filter(e => e.ts >= cutoff).length; sendResponse({ ...state, last30Count: count30 }); }
  else if (msg.type === 'addRule') { const { rules } = await getState(); const type = (msg.matchType === 'domain') ? 'domain' : 'keyword'; const newRule = { pattern: msg.pattern, type, enabled: true }; if (type === 'domain' && msg.hidden === true) newRule.hidden = true; rules.push(newRule); await chrome.storage.sync.set({ rules }); await compileRulesFromStorage(); await purgeExistingHistory(); sendResponse({ ok: true }); }
  else if (msg.type === 'removeRule') { const { rules } = await getState(); if (typeof msg.index === 'number' && rules[msg.index]) { rules.splice(msg.index, 1); await chrome.storage.sync.set({ rules }); await compileRulesFromStorage(); } sendResponse({ ok: true }); }
  else if (msg.type === 'toggleRule') { const { rules } = await getState(); if (typeof msg.index === 'number' && rules[msg.index]) { rules[msg.index].enabled = !rules[msg.index].enabled; await chrome.storage.sync.set({ rules }); await compileRulesFromStorage(); await purgeExistingHistory(); } sendResponse({ ok: true }); }
  else if (msg.type === 'resetCounter') { const { counters } = await getState(); counters.deletedCount = 0; counters.lastReset = new Date().toISOString().slice(0,10); await chrome.storage.sync.set({ counters }); sendResponse({ ok: true }); }
  else if (msg.type === 'clearLogs') { await chrome.storage.sync.set({ logs: [] }); sendResponse({ ok: true }); }
  else if (msg.type === 'exportState') { const state = await getState(); sendResponse({ state }); }
  else if (msg.type === 'purgeNow') { await purgeExistingHistory(); sendResponse({ ok: true }); }
})(); return true; });

// *** HOTFIX: Run initial setup immediately when worker starts ***
(async () => { try { setupContextMenus(); await compileRulesFromStorage(); log('worker initialized'); } catch(e){ warn('initial setup failed', e); } })();
